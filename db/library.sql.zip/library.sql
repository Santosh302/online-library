-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 10, 2019 at 11:35 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE IF NOT EXISTS `adminlogin` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `massage` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `subject`, `massage`) VALUES
(1, 'santosh kumar yadav', 'wesrdtfyu@asdfgh', 'asdfghj', 'weertyui'),
(2, 'santosh kumar', 'wesrdtfyu@asdfgh', 'asdfghj', 'weertyuifdgfhj');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `moblie` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(20) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `city` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `name`, `moblie`, `email`, `password`, `gender`, `city`) VALUES
(1, 'nb ', '87', 'a@gmail.com', 'jhbjhb', 'on', 'Meghalaya'),
(2, 'sanjay kumar yadav', '7355651198', 'sanjay@123gmail.com', 'erhgj', 'on', 'Andhra Pradesh'),
(3, 'santosh kumar yadav', '1234567', 'sdfgh@edrfghj', 'asdfghj', 'on', 'Andhra Pradesh'),
(4, 'harsh yadav', '639311336', 'garsg@gmail.com', 'adfghnm,', 'on', 'Andhra Pradesh'),
(6, 'cpy', '23456', 'cpy@gmail.com', '98765', 'on', 'Karnataka'),
(7, 'santosh yadav', '7355651198', 'santoshkumarsy05@gmail.com', '123455678', 'on', 'Utter pradesh'),
(8, 'harsh yadav', '6393113366', '6393113366a@gmail.com', '123', 'on', 'Jammu and kasmir'),
(9, 'ajay', '8112450800', 'ajay@gmail.com', '12345678', 'on', 'Utter pradesh');
